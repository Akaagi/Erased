Merci d'avoir installé notre jeu !

Un dossier d'exploitation est disponible pour vous aider à installer et désinstaller le jeu.
Veuillez vous y référer en cas de doute ou si vous avez une question sur l'ensemble du gameplay
en solo comme en multijoueur.
Amusez-vous bien !

Voici quelques liens utiles :

Notre site : https://topagrume.github.io/erased/accueil.html
Notre Twitter : https://twitter.com/project_erased
